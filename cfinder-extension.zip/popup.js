
document.addEventListener("DOMContentLoaded", () => {
    const input = document.getElementById("link");
    const messageBox = document.getElementById("message");

    // Charger le lien sauvegardé
    chrome.storage.local.get("pixeldrain_link", (data) => {
        if (data.pixeldrain_link) {
            input.value = data.pixeldrain_link;
            showMessage("✅ Lien chargé", "green");
        }
    });

    // Enregistrer et remplir
    document.getElementById("submit").addEventListener("click", async () => {
        const url = input.value.trim();
        if (!url.startsWith("http") || !url.includes("/u/")) {
            showMessage("❌ Lien Pixeldrain invalide.", "red");
            return;
        }

        chrome.storage.local.set({ pixeldrain_link: url });

        const fileId = url.split("/").pop();
        try {
            const metadataUrl = `https://pixeldrain.com/api/file/${fileId}/info`;
            const res = await fetch(metadataUrl);
            const data = await res.json();

            const rawName = data.name.replace(".rar", "");
            const [titleAndVersion, authorPart] = rawName.split(" by ");
            const [title, version] = titleAndVersion.split(" -");

            const finalData = {
                nameOnly: title?.trim().split(" Build")[0],
                version: version?.trim(),
                author: authorPart?.replace(/[{}]/g, "").trim(),
                link: url
            };

            chrome.tabs.query({ active: true, currentWindow: true }, ([tab]) => {
                chrome.scripting.executeScript({
                    target: { tabId: tab.id },
                    func: autoFillForm,
                    args: [finalData]
                });
            });

            showMessage("✅ Formulaire rempli.", "green");
        } catch (e) {
            console.error(e);
            showMessage("❌ Erreur lecture fichier.", "red");
        }
    });

    // Réinitialiser le lien
    document.getElementById("reset").addEventListener("click", () => {
        chrome.storage.local.remove("pixeldrain_link", () => {
            input.value = "";
            showMessage("🔁 Lien réinitialisé.", "orange");
        });
    });

    function showMessage(text, color) {
        messageBox.innerText = text;
        messageBox.style.color = color;
    }
});

function autoFillForm({ nameOnly, version, author, link }) {
    const url = window.location.href;

    if (url.includes("step1.php")) {
        const steamInput = document.querySelector('input[name="id_steam"]');
        if (steamInput) steamInput.value = nameOnly;
        return;
    }

    if (url.includes("step2.php")) {
        const creditInput = document.getElementById("credit");
        const versionInput = document.getElementById("version");
        if (creditInput) creditInput.value = version;
        if (versionInput) versionInput.value = "";
        return;
    }

    if (url.includes("step2-5.php")) {
        const linkInput = document.querySelector('input[placeholder="Lien Premium"]');
        if (linkInput) linkInput.value = link;
        return;
    }

    alert("Cette page n'est pas supportée.");
}
